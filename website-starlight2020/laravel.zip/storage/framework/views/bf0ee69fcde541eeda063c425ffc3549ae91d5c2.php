<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Starlight 2020 - <?php echo e($title); ?></title>

    <!-- Icon Starlight -->
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('css/panel/bootstrap/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/panel/plugins.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- END GLOBAL MANDATORY STYLES -->
    
    <!-- BEGIN PAGE LEVEL STYLES -->
    <?php echo $__env->yieldContent('custom_css'); ?>
    <!-- END PAGE LEVEL STYLES -->
    <?php echo $__env->yieldContent('custom_css'); ?>
</head>
<body class="sidebar-noneoverflow">
	<!-- BEGIN NAVBAR -->
  	<?php echo $__env->make('panel.template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
    <!-- END NAVBAR -->

    <!--  BEGIN MAIN CONTAINER  -->
    <div class="main-container" id="container">

        <div class="overlay"></div>
        <div class="search-overlay"></div>

        <!--  BEGIN TOPBAR  -->
        <?php echo $__env->make('panel.template.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
        <!--  END TOPBAR  -->

        <!--  BEGIN CONTENT AREA  -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- BEGIN FOOTER -->
        <?php echo $__env->make('panel.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
        <!-- END FOOTER -->
        <!-- END CONTENT AREA -->      
    </div>     
    <!-- END MAIN CONTAINER -->

    <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="<?php echo e(asset('js/panel/jquery/jquery-3.1.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/panel/bootstrap/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/panel/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/panel/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/panel/app.js')); ?>"></script>
    
    <script>
        $(document).ready(function() {
            App.init();
        });
    </script>
    <script src="<?php echo e(asset('js/panel/custom.js')); ?>"></script>
    <!-- END GLOBAL MANDATORY SCRIPTS -->

    <!-- BEGIN PAGE LEVEL SCRIPTS -->
    <?php echo $__env->yieldContent('custom_js'); ?>
    <!-- END PAGE LEVEL SCRIPTS -->
</body>
</html><?php /**PATH C:\Users\Christianto Vinsen\Documents\Projects\Website Starlight 2020\cloned\Starlight2020_Laravel\website-starlight2020\resources\views/panel/template/base.blade.php ENDPATH**/ ?>