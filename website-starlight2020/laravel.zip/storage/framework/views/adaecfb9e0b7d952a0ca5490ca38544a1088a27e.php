<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Starlight 2020 - <?php echo e($title); ?></title>

    <!-- Icon Starlight -->
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

    <!-- BEGIN: CSS Assets-->
    <link rel="stylesheet" href="<?php echo e(asset('css/panel/app.css')); ?>" />
    <!-- END: CSS Assets-->
</head>
<body class="login">
    <div class="container sm:px-10">
        <div class="block xl:grid grid-cols-2 gap-4">
            <div class="hidden xl:flex flex-col min-h-screen">
                <div class="my-auto">
                    <img alt="Midone Tailwind HTML Admin Template" class="-intro-x" width="400" src="<?php echo e(asset('images/core-img/Logo_starlight_fix.png')); ?>">
                    <div class="-intro-x text-white font-medium text-4xl leading-tight mt-10">
                        Starlight 2020
                    </div>
                    <div class="-intro-x mt-5 text-lg text-white"> Universitas Multimedia Nusantara </div>
                </div>
            </div>
            <div class="h-screen xl:h-auto flex xl:py-0 xl:my-0">
                <div class="my-auto mx-auto xl:ml-20 bg-white xl:bg-transparent px-5 sm:px-8 py-8 xl:p-0 rounded-md shadow-md xl:shadow-none w-full sm:w-3/4 lg:w-2/4 xl:w-auto">
                    <h2 class="intro-x font-bold text-2xl xl:text-3xl text-center xl:text-left">
                        Sign In
                    </h2>
                    <div class="intro-x mt-2 text-gray-500 xl:hidden text-center"> Starlight UMN 2020</div>
                    <div class="intro-x mt-8">
                        <input type="text" class="intro-x login__input input input--lg border border-gray-300 block" placeholder="Email">
                        <input type="password" class="intro-x login__input input input--lg border border-gray-300 block mt-4" placeholder="Password">
                    </div>
                    <div class="intro-x mt-5 xl:mt-8 text-center xl:text-left">
                        <button class="button button--lg w-full xl:w-32 text-white bg-theme-1 xl:mr-3">Login</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('js/panel/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Users\Christianto Vinsen\Documents\Projects\Website Starlight 2020\cloned\Starlight2020_Laravel\website-starlight2020\resources\views/admin/login.blade.php ENDPATH**/ ?>