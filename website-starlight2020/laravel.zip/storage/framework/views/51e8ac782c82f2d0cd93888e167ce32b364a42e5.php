<div class="footer-wrapper">
        <div class="footer-section f-section-1">
            <p class="">Copyright © 2020 Starlight, All rights reserved.</p>
        </div>
    </div>
</div><?php /**PATH C:\Users\Christianto Vinsen\Documents\Projects\Website Starlight 2020\cloned\Starlight2020_Laravel\website-starlight2020\resources\views/panel/template/footer.blade.php ENDPATH**/ ?>